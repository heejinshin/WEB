const toggleBtn = document.querySelector(".navbar__toogleBtn");
const menu = document.querySelector(".navbar__menu");
const login = document.querySelector(".navbar__login");

toggleBtn.addEventListener("click", () => {
  menu.classList.toggle("active");      /*classlist는 읽기전용속성이다,클래스목록에 접근하는방식*/
  login.classList.toggle("active");
});
