const toDoForm = document.querySelector(".dr-toDoForm"),
/*todoForm 을 지정할거야, 건드릴 수 없는 상수로, html에서 클래스가()인 요소들을 가져와서*/
  toDoInput = toDoForm.querySelector("input"),
  /*todoinput은 뭐냐면 위에서 지정한 todoform에서 input태그인 애들 가져와서 따로 뺄거야*/
  toDoList = document.querySelector(".dr-show-toDolist");
  /*todolist가 뭐냐면 html문서에서 클래스가todolist인 애들 가져와서 지정할거야*/

const TODO_LS = "toDos";
/*todo_ls라는 변수를 만들어야겠어 todos라는 문자열을 넣어줄게*/

let toDos = [];
/*todos 는 위에서 지정한 todo_ls상수지? 그안에 배열을 줄 공간을 만들어 둘거야*/
function deleteToDo(event) {
  /*함수를 지정해 deletetodo라고 그 안에 event를 해줄거야*/
  const btn = event.target;
  /*btn이라는 상수를 지정해 상수는 건드릴수 없어, event안에 target해줘*/
  const li = btn.parentNode;
  toDoList.removeChild(li);
  const cleanToDos = toDos.filter(function (toDo) {
    return toDo.id !== parseInt(li.id);
  });
  toDos = cleanToDos;
  saveToDos();
}

function saveToDos() {
  localStorage.setItem(TODO_LS, JSON.stringify(toDos));
}

function paintToDo(text) {
  const li = document.createElement("li");
  const delBtn = document.createElement("button");
  delBtn.innerText = "❌";
  delBtn.addEventListener("click", deleteToDo);
  const span = document.createElement("span");
  const newId = toDos.length + 1;
  span.innerText = text;
  li.appendChild(span);
  li.appendChild(delBtn);
  delBtn.classList.add("deleteBtn-todo"); /* 생성된 element에 클래스이름 설정*/
  li.id = newId;
  toDoList.appendChild(li);
  const toDoObj = {
    text: text,
    id: newId,
  };
  toDos.push(toDoObj);
  saveToDos();
}

function handleSubmit(event) {
  event.preventDefault();
  const currentValue = toDoInput.value;
  paintToDo(currentValue);
  toDoInput.value = "";
}

function loadToDos() {
  const loadedToDos = localStorage.getItem(TODO_LS);
  if (loadedToDos !== null) {
    const parsedToDos = JSON.parse(loadedToDos);
    parsedToDos.forEach(function (toDo) {
      paintToDo(toDo.text);
    });
  }
}

function init() {
  loadToDos();
  toDoForm.addEventListener("submit", handleSubmit);
}

init();
